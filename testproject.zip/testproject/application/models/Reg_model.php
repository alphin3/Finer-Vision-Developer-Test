<?php
class Reg_model extends CI_Model
{

	function saverecords($data)
	{
        $this->db->insert('registration',$data);
        return true;
	}
	public function save_forms($data_array,$type){
		if($type==1){
			$this->db->insert('form_one',$data_array);
			$last_insert_id=$this->db->insert_id();
		}
		if($type==2){
			$this->db->insert('form_two',$data_array);
			$last_insert_id=$this->db->insert_id();
		}
		if($type==3){
			$this->db->insert('form_three',$data_array);
		  $last_insert_id=true;
		}
		return $last_insert_id;
	}

}
