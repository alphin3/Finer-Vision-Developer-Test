<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	 public function __construct() {
						parent::__construct();
						 $this->load->helper('url');
						 $this->load->database();
						 $this->load->model('Reg_model');
	}

	public function index()
	{
		$this->load->view('welcome_message');
	}
	public function save_registration()
	{

		$name=$this->input->get('name');
		$email_id=$this->input->get('email');
		$phone=$this->input->get('phone');
		$password=$this->input->get('password');
		$data_array=array(
			'name'=>$name,
			'email_id'=>$email_id,
			'password'=>$password,
			'phone'=>$phone
		);
		$result=$this->Reg_model->saverecords($data_array);
		echo $result;
	}
	public function saveform()
	{
		$data_array=array();
		if($this->input->post('add_type')=='form1'){
			$data_array=array(
				'first_name' => $this->input->post('first_name'),
				'sure_name' => $this->input->post('sure_name'),
				'address' => $this->input->post('address'),
			);
			$result=$this->Reg_model->save_forms($data_array,1);
			echo $result;
		}
		$data_array=array();
		if($this->input->post('add_type')=='form2'){
			$data_array=array(
				'teliphone' => $this->input->post('teliphone'),
				'gender' => $this->input->post('gender'),
				'date_of_birth' => $this->input->post('date_of_birth'),
				'form_one_id'=>$this->input->post('hidden__table_id'),
			);
			$result1=$this->Reg_model->save_forms($data_array,2);
			echo $result1;
		}
		$data_array=array();
		if($this->input->post('add_type')=='form3'){
			$data_array=array(
				'comments' => $this->input->post('comments'),
				'form_two_id'=>$this->input->post('hidden__table_id1'),
			);
			$this->Reg_model->save_forms($data_array,3);
			echo true;
		}
	}
}
