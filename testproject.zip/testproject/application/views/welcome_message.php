<script type="text/javascript" src="<?= base_url() ?>web/jquery.min.js"></script>
<link rel="stylesheet" href="<?= base_url() ?>web/bootstrap.min.css">
<link rel="stylesheet" href="<?= base_url() ?>web/bootstrap1.min.css">
<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="<?= base_url() ?>web/bootstrap2.min.js"></script>
</head>
<body>

<div class="container" style="margin-top:10%;">
  <h2>Finer Vision Developer Test</h2>
<div class="panel-group" id="accordion">
    <div class="panel panel-default">
      <div class="panel-heading" style="background-color:orange" >
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse1">Step1:Your Details</a>
        </h4>
      </div>
      <div id="collapse1" class="panel-collapse collapse in">
        <form id="form_save" action="<?= base_url() ?>welcome/saveform" name="form_save">
        <div class="panel-body">
          <div class="row">
           <div class="col-md-12">
             <div class="col-md-6">
               <label>First Name</label>
               <input type="text" name="first_name" class="form-control">
             </div>
             <div class="col-md-6">
                 <label>Sure Name</label>
                 <input type="text" name="sure_name" class="form-control">
             </div>
           </div>
           <div class="col-md-12">
             <div class="col-md-6">
                 <label>Address</label>
                 <input type="text" name="address" class="form-control">
             </div>
           </div>
         </div>
         <div>
           <button style="float:right;margin-right:2%;margin-top:3%" type="submit" class="btn btn-info">Next</button>
         </div>
        </div>
        </form>
    </div>
    <div class="panel panel-default">
      <div class="panel-heading" style="background-color:orange">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse2">Step 2:More Comments</a>
        </h4>
      </div>
      <div id="collapse2" class="panel-collapse collapse">
        <form id="form_save1" action="<?= base_url() ?>welcome/saveform" name="form_save1">
        <div class="panel-body">
          <div class="row">
           <div class="col-md-12">
             <div class="col-md-6">
               <input type="hidden" name="hidden__table_id" id="hidden__table_id" value="">
               <label>Teliphone No</label>
               <input type="text" name="teliphone" class="form-control">
             </div>
             <div class="col-md-6">
                 <label>Gender</label>
                 <select name="gender" class="form-control">
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                 </select>
             </div>
           </div>
           <div class="col-md-12">
             <div class="col-md-6">
                 <label>Date Of Birth</label>
                 <input type="text" name="date_of_birth" class="form-control">
             </div>
           </div>
         </div>
         <div>
           <button style="float:right;margin-right:2%;margin-top:3%" type="submit" class="btn btn-info">Next</button>
         </div>
        </div>
      </form>
    </div>
    <div class="panel panel-default">
      <div class="panel-heading" style="background-color:orange">
        <h4 class="panel-title">
          <a data-toggle="collapse" data-parent="#accordion" href="#collapse3">Step 3:Final Comments</a>
        </h4>
      </div>
      <div id="collapse3" class="panel-collapse collapse">
        <form id="form_save2" action="<?= base_url() ?>welcome/saveform" name="form_save2">
        <div class="panel-body">
          <div class="row">
           <div class="col-md-12">
             <div class="col-md-12">
               <input type="hidden" id="hidden__table_id1" name="hidden__table_id1">
               <label>Comments</label>
               <textarea class="form-control" name="comments"></textarea>
             </div>
           </div>
         </div>
         <div>
           <button style="float:right;margin-right:2%;margin-top:3%" type="submit" class="btn btn-info">Next</button>
         </div>
        </div>
      </form>
    </div>

  </div>
</div>
<div id="success_msg"  class="alert alert-success" style="margin-top:2%">Data save completed</div>
</body>
</html>
<script>

$("#form_save").submit(function(e){
        e.preventDefault();
        var obj = $(this), action = obj.attr('name');
        $.ajax({
        type: "POST",
        url: e.target.action,
        data: obj.serialize()+"&is_ajax=1&add_type=form1&form="+action,
        cache: false,
        success: function (JSON) {
          $('#collapse1').hide();
          $('#collapse2').show();
          $('#hidden__table_id').val(JSON);
        }
    });
});

$("#form_save1").submit(function(e){
        e.preventDefault();
        var obj = $(this), action = obj.attr('name');
        $.ajax({
        type: "POST",
        url: e.target.action,
        data: obj.serialize()+"&is_ajax=1&add_type=form2&form="+action,
        cache: false,
        success: function (JSON) {

            $('#collapse2').hide();
            $('#collapse3').show();
            $('#hidden__table_id1').val(JSON);
        }
    });
});
$("#form_save2").submit(function(e){
        e.preventDefault();
        var obj = $(this), action = obj.attr('name');
        $.ajax({
        type: "POST",
        url: e.target.action,
        data: obj.serialize()+"&is_ajax=1&add_type=form3&form="+action,
        cache: false,
        success: function (JSON) {
        //  $('#collapse2').hide();
          $('#collapse3').hide();
          if(JSON==1){
    					$('#success_msg').show();
    					setInterval(function () {
    							$('#success_msg').hide();
    					}, 1000);
              location.reload();
          }

        }
    });
});
$(document).ready(function(){
  $('#success_msg').hide();
});
function registration(){
	var name=$('#name').val();
//	alert(name);
	var email=$('#email').val();
	var phone=$('#phone').val();
	var password=$('#password').val();
	$.ajax({
		url: "<?= base_url() ?>welcome/save_registration",
		type: "GET",
		data:  {name:name,email:email,phone:phone,password:password},
		success: function(JSON)
		{
		    if(JSON==1){
					$('#success_msg').show();
					setInterval(function () {
							$('#success_msg').hide();
					}, 1000);
				}

		},
		error: function()
		{

		}
   });
}
</script>
